#include<stdio.h>
#include<stdlib.h>
#include<termios.h>
#include<unistd.h>
#include"psw.c"
int cnt=0;
#include"linkedlist.c"
#include"doublelist.c"
int main(){
	int ch,k,key=3;
	check :
	k=psw();
	system("clear");
	if(k)while(1){
		system("clear");
		printf("\n\n\t\t...........Enter your choice..........");
		printf("\n\n\t1:\tData structure using singly linked list");
		printf("\n\n\t2:\tData structure using doubly linked list");
		printf("\n\n\t3:\tExit from the program\t");
		ch=getch();
		switch(ch){
		case 49:linkedlist();
			break;
		case 50:doublelist();
			break;
		case 51:printf("\n");
			return 0;
		}
	}key--;
	if(!key){
		printf("\n\n\tSorry .!!!!---Exceeds maximum trial limit...Deleteing all the files\n\n\n\n\t");
		system("rm -rf *txt");
		return 0;
	}
	printf("\n\n\tUsername or password is wrong...!!!!");
	printf("\n\n\tCAUTION : FILES WILL BE DELETED AFTER %d TRIALS",key);
	printf("\n\n\tWant to continue....press y : ");
	ch=getche();
	if((char)ch=='y'||(char)ch=='Y')
	goto check;
	printf("\n");return 0;
}


