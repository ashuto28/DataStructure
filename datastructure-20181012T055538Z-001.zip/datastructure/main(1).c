#include<stdio.h>
#include<stdlib.h>
#include<termios.h>
#include<unistd.h>
#include"psw.c"
int cnt=0;
#include"linkedlist.c"
#include"doublelist.c"
void main(){
	int ch,key;
	key=psw();
	while(1){
		system("clear");
		printf("\n\n\t\t...........Enter your choice..........");
		printf("\n\n\t1:\tData structure using singly linked list");
		printf("\n\n\t2:\tData structure using doubly linked list");
		printf("\n\n\t3:\tExit from the program\t");
		ch=getch();
		switch(ch){
		case 49:linkedlist();
			break;
		case 50:doublelist();
			break;
		case 51:printf("\n");
			return;
		}
	}	
}


