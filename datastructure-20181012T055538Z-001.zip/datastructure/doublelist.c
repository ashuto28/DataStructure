#include<stdio.h>
#include<stdlib.h>
#include<termios.h>
#include<unistd.h>
struct double_linked_list
{
	int data;
	struct double_linked_list *next;
	struct double_linked_list *prev;
}*top1=NULL;
typedef struct double_linked_list node1;

void create1();
void add1();
void display1();
void count1();
void delete1();
void clear1();
void reverse1();
void shrt1();
void search1();
int getch1();
int getche1();

int doublelist()
{
	int che;
	while(1)
	{
	system("clear");
	system("clear");
	printf("\n\t\t--------Enter your choice------\n\n");
	printf("\t1:\tCreate a doubly linked list\n");
	printf("\t2:\tAdd an element to the doubly linked list\n");
	printf("\t3:\tDisplay elements in the doubly linked list\n");
	printf("\t4:\tcount the total number of elements in the doubly linked list\n");
	printf("\t5:\tRevers the given doubly linked list\n");	
	printf("\t6:\tShort the element\n");
	printf("\t7:\tSearch an element in doubly linked list\n");
	printf("\t8:\tDelete an element from the doubly linked list");
	printf("\n\t9:\tGo to main menu\t");
	che=getch1();
		switch(che){
		case 49: create1();
			 break;
		case 50: add1();
			 break;
		case 51: display1();
			 break;
		case 52: count1();
			 system("clear");
			 printf("\n\n\tTotal number of element in the doubly linked list is : %d",cnt);
			 getch1();	
			 break;
		case 53: reverse1();
			 break;
		case 54: shrt1();
			 break;
		case 55: search1();
	       		 break;
		case 56: delete1();
	       		 break;
		case 57: printf("\n");
	       		 return 0;
		}
	}
}
void create1()
{
	node1 *temp;
	if(top1!=NULL){
	system("clear");
	printf("\n\n\tLinked list is already being created....");	
	}
	else{
		system("clear");
		temp=(node1*)malloc(sizeof(node1));
		printf("\n\n\tEnter the data ");
		scanf("%d",&(temp->data));
		temp->next=NULL;
		temp->prev=NULL;
		top1=temp;		
	}
	getch1();
}
void search1()
{
	int pos=0,flag=0,data;
	node1 *temp;
	if(top1==NULL){
	system("clear");
 	printf("\n\n\tERROR...Underflow!!!!!!!!");
	getch1();
	return;
	}
	system("clear");
	printf("\n\n\tEnter the element to be searched : ");
	scanf("%d",&data);
	temp=top1;
	while(temp!=NULL){
		if(temp->data!=data){
		pos++;
		temp=temp->next;	
		}
		else{
		pos++;
		flag=1;
		break;
		}
	}
	if(flag)
	printf("\n\tThe element %d is found at position : %d",data,pos);
	else
	printf("\n\tThe element %d is not fount in the doubly linked list ",data);
	clear1();
	getch1();
}
void shrt1()
{
	node1 *temp1,*temp2,*temp3;;
	int temp;
	if(top1==NULL){
	system("clear");
 	printf("\n\n\tERROR...Underflow!!!!!!!!");
	getch1();
	return;
	}
	temp3=NULL;
	temp1=top1;
	while(temp1->next!=NULL){
		temp2=top1;
		while(temp2->next!=temp3){
			if(temp2->data>temp2->next->data){
				temp=temp2->next->data;
				temp2->next->data=temp2->data;
				temp2->data=temp;	
			}
			temp2=temp2->next;
		}
		temp3=temp2;
		temp1=temp1->next;	
	}
	system("clear");
	printf("\n\n\tShorting successfull....");
	getch1();

}
void display1()
{
	node1 *temp;
	temp=top1;
	if(temp==NULL){
	system("clear");
 	printf("\n\n\tERROR...Underflow!!!!!!!!");
	}
	else{
		system("clear");
		printf("\n\n\tThe doubly linked list is :\n\t");
	while(temp!=NULL){
		if(temp!=top1){
		printf("<-->%d",temp->data);
		temp=temp->next;
		}
		else{
		printf("%d",temp->data);
		temp=temp->next;
		}	
	  }
	}
	printf("\t");
	getch1();

}
void add1()
{
	node1 *temp,*temp2,*temp1;;
	int  loc,i,ch;
	if(top1==NULL){
	system("clear");
	printf("\n\n\tDoubly linked list is not created ....!!!\n\t");
	getch1();
	}
	else{
	while(1){
		system("clear");
		printf("\n\t\t\t--------Enter your choice------\n\n");
		printf("\t1:\tAdd an element at the begining of the doubly linked list\n");
		printf("\t2:\tAdd an element to the end of the doubly linked list\n");
		printf("\t3:\tAdd an element at any location of the doubly linked list\n");
		printf("\t4:\tAbort insertion opreration\n\t");
		ch=getch1();
		switch(ch){
		case 49:temp=(node1*)malloc(sizeof(node1));
			system("clear");
			if(temp==NULL)
				printf("\n\n\tError ....overflow!!!!!!");
			else{
			 	printf("\n\tEnter the data : ");
			 	scanf("%d",&temp->data);
				clear1();
			 	temp->next=top1;
			 	temp->prev=NULL;
				top1->prev=temp;
			 	top1=temp;
			 	printf("\n\tAddition successfull.....\n\t");
			 }
			getch1();
			break;
		case 50:temp=(node1*)malloc(sizeof(node1));
			system("clear");
			if(temp==NULL)
				printf("\n\n\tError ....overflow!!!!!!");
			 else{
				printf("\n\tEnter the data : ");
				scanf("%d",&temp->data);
				clear1();
				temp2=top1;
				while(temp2->next!=NULL)
					temp2=temp2->next;
				temp2->next=temp;
				temp->prev=temp2;
				temp->next=NULL;
				printf("\n\tAddition successfull.....\n\t");
			}
			getch1();
			break;
		case 51:temp=(node1*)malloc(sizeof(node1));
			system("clear");
			if(temp==NULL)
				printf("\n\n\tError ....overflow!!!!!!");
			else{
				printf("\n\tEnter the data : ");
				scanf("%d",&temp->data);
				printf("\n\tEnter the location : ");
				scanf("%d",&loc);
				clear1();
				count1();
				if(loc>=cnt||loc<=1){
					if(loc==cnt)
						printf("\nAddition of data at the end can not be performed");
					else if(loc==1)
						printf("\nAddition of data at the begning can not be performed");
					else
						printf("\n\tLocation does not exist");
					free(temp);
				}
				else{
					temp2=top1;
					for(i=1;i<loc;i++)
						temp2=temp2->next;
					temp->next=temp2;
					temp->prev=temp2->prev;
					temp2->prev->next=temp;
					temp2->prev=temp;
					printf("\n\tAddition successfull.....\n\t");
				}
			}
			getch1();
			break;
		case 52: system("clear");
			 printf("\n\n\tAddition of data aborted......!!!!\n\t");
			 getch1();
			 return;	
		}
		}
	}	
}
void count1()
{
	cnt=0;
	node1 *temp;
	temp=top1;
	while(temp!=NULL)
	{
	cnt++;
	temp=temp->next;	
	}
}
void reverse1()
{
	node1 *temp,*temp1;
	if(top1==NULL)
	{
	system("clear");
	printf("\n\n\tError ...Underflow!!!!!!!!");
	}
	else
	{
		temp=top1;
		system("clear");
		while(1)
		{
			temp1=temp->next;
			temp->next=temp->prev;
			temp->prev=temp1;
			if(temp1==NULL)
			{
			top1=temp;
			break;
			}
			else
			temp=temp1;
		}
		printf("\n\n\tDoubly Linked list reversed....\n\t");		
	}
	getch1();
}
void delete1()
{	
	node1 *temp;
	int data;
	int ch;
	if(top1==NULL)
	{
	system("clear");
	printf("\n\n\tError ...Underflow!!!!!!!!");
	}
	else
	{
	system("clear");
	printf("\n\n\tEnter the element to be deleted : ");
	scanf("%d",&data);
	clear1();
	{
		temp=top1;
		while(temp->data!=data && temp->next!=NULL)
		{
		temp=temp->next;
		}
		if(temp->data==data)
		{
			printf("\n\tDeleting age = %d from the doubly linked list ....to continue press y : ",data);
			ch=getche1();
			if((char)ch=='y'||(char)ch=='Y')
			{
				if(temp==top1)
				{
				top1->prev=NULL;
				top1=top1->next;	
				}		
				else if(temp->next==NULL)
				temp->prev->next=NULL;
				else
				{
				temp->prev->next=temp->next;
				temp->next->prev=temp->prev;
				}
				free(temp);
				printf("\n\n\tDeletion successfull...");
			}
			else
			printf("\n\n\tDeletion of data aborted...!!!");
		}
		else
		printf("\n\tElement not found in the doubly linked list\n\t");
	}	
	}
	getch1();
}
int getch1()
{
    struct termios oldattr, newattr;
    int ch;
    tcgetattr( STDIN_FILENO, &oldattr );
    newattr = oldattr;
    newattr.c_lflag &= ~( ICANON | ECHO );
    tcsetattr( STDIN_FILENO, TCSANOW, &newattr );
    ch = getchar();
    tcsetattr( STDIN_FILENO, TCSANOW, &oldattr );
    return ch;
}
int getche1()
{
    struct termios oldattr, newattr;
    int ch;
    tcgetattr( STDIN_FILENO, &oldattr );
    newattr = oldattr;
    newattr.c_lflag &= ~( ICANON );
    tcsetattr( STDIN_FILENO, TCSANOW, &newattr );
    ch = getchar();
    tcsetattr( STDIN_FILENO, TCSANOW, &oldattr );
    return ch;
}
void clear1()
{
while(getchar()!=10);
}

