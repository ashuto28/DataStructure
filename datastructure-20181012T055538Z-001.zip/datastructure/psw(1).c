#include<stdio.h>
#include<stdlib.h>
#include <termios.h>
#include <unistd.h>

int getch2(void)
{
    struct termios oldattr, newattr;
    int ch;
    tcgetattr( STDIN_FILENO, &oldattr );
    newattr = oldattr;
    newattr.c_lflag &= ~( ICANON | ECHO );
    tcsetattr( STDIN_FILENO, TCSANOW, &newattr );
    ch = getchar();
    tcsetattr( STDIN_FILENO, TCSANOW, &oldattr );
    return ch;
}

int  psw()
{
	char u_name[20],psw[20];
	int i=-1,ch;
	system("clear");
	printf("\n\n\tEnter the user name : ");
	gets(u_name);
	printf("\n\n\tEnter the password : ");
	while((ch=getch2())!=10){
		if(ch==127){
			i--;
			printf("%c[1D",0X1B);
			printf("%c[K",0X1B);
			continue;	
		
		}
			i++;
			psw[i]=ch;
			printf("*");
		
	}
	i++;
	psw[i]='\0';
	printf("\n\n\tThe username is : \t%s\n",u_name);
	printf("\n\tThe password is : \t%s",psw);
	getch2();
	return 1;	
	
}
