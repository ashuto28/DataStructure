#include<stdio.h>
#include<stdlib.h>
#include<termios.h>
#include<unistd.h>
struct linked_list
{
	int data;
	struct linked_list *next;
}*top=NULL;
typedef struct linked_list node;
void create();
void add();
void display();
void count();
void delete();
void clear();
void reverse();
void shrt();
void search();
int getch();
int getche();
int linkedlist()
{
	int che;
	while(1)
	{
	system("clear");
	system("clear");
	printf("\n\t\t--------Enter your choice------\n\n");
	printf("\t1:\tCreate a linked list\n");
	printf("\t2:\tAdd an element to the linked list\n");
	printf("\t3:\tDisplay elements in the linked list\n");
	printf("\t4:\tcount the total number of elements in the linked list\n");
	printf("\t5:\tRevers the given linked list\n");	
	printf("\t6:\tShort the element\n");
	printf("\t7:\tSearch an element in linked list\n");
	printf("\t8:\tDelete an element from the linked list");
	printf("\n\t9:\tGo to main menu\t");
	che=getch();
		switch(che){
		case 49: create();
			 break;
		case 50: add();
			 break;
		case 51: display();
			 break;
		case 52: count();
			 system("clear");
			 printf("\n\n\tTotal number of element in the linked list is : %d",cnt);
			 getch();	
			 break;
		case 53: reverse();
			 break;
		case 54: shrt();
			 break;
		case 55: search();
	       		 break;
		case 56: delete();
	       		 break;
		case 57: printf("\n");
	       		 return 0;
		}
	}
}
void create()
{
	node *nd;
	if(top!=NULL)
	{
	system("clear");
	printf("\n\n\tLinked list is already being created....");
	
	}
	else
	{	system("clear");
		nd=(node*)malloc(sizeof(node));
		printf("\n\n\tEnter the data ");
		scanf("%d",&(nd->data));
		nd->next=NULL;
		top=nd;		
	}
	getch();


}
void search()
{
	int pos=0,flag=0,data;
	node *temp;
	if(top==NULL){
	system("clear");
 	printf("\n\n\tERROR...Underflow!!!!!!!!");
	getch();
	return;
	}
	system("clear");
	printf("\n\n\tEnter the element to be searched : ");
	scanf("%d",&data);
	temp=top;
	while(temp!=NULL){
		if(temp->data!=data){
		pos++;
		temp=temp->next;	
		}
		else{
		pos++;
		flag=1;
		break;
		}
	}
	if(flag)
	printf("\n\tThe element %d is found at position : %d",data,pos);
	else
	printf("\n\tThe element %d is not fount in the linked list ",data);
	clear();
	getch();
}
void display()
{
	node *temp;
	temp=top;
	if(temp==NULL){
	system("clear");
 	printf("\n\tERROR...Underflow!!!!!!!!");
	}
	else
	{
	system("clear");
	printf("\n\tThe linked list is :\n\t");
	while(temp!=NULL)
	{
		if(temp!=top){
		printf("-->%d",temp->data);
		temp=temp->next;
	}
	else
	{
		printf("%d",temp->data);
		temp=temp->next;
	}	
	}
	}
	printf("\t");
	getch();

}
void reverse()
{
	node *temp,*temp2,*temp3,*temp4;
	if(top==NULL)
	{
	system("clear");
	printf("\n\n\tError ...Underflow!!!!!!!!");
	}
	else
	{
		count();
		system("clear");
		temp2=(node *)malloc(sizeof(node));
		temp3=temp2;
		while(cnt)
		{
			temp=top;			
			while(temp->next!=NULL)
			{
				temp4=temp;
				temp=temp->next;
			}
			temp2->data=temp->data;
			if(cnt>1)
			{	temp2->next=(node *)malloc(sizeof(node));
				temp2=temp2->next;
			}
			else
			temp2->next=NULL;
			temp4->next=NULL;
			free(temp);
			cnt--;
		}
		top=temp3;
		printf("\n\n\tLinked list reversed....\n\t");		
	}
	getch();
}
void add()
{
	node *temp,*temp2,*temp1;;
	int ch,loc,i;
	if(top==NULL){
	system("clear");
	printf("\n\n\tLinked list is not created ....!!!\n\t");
	getch();
	}
	else{
	while(1){
		system("clear");
		printf("\n\t\t\t--------Enter your choice------\n\n");
		printf("\t1:\tAdd an element at the begining of the linked list\n");
		printf("\t2:\tAdd an element to the end of the linked list\n");
		printf("\t3:\tAdd an element at any location of the linked list\n");
		printf("\t4:\tAbort insertion opreration\n\t");
		ch=getch();
		system("clear");
		switch(ch){
		case 49:temp=(node*)malloc(sizeof(node));
			if(temp==NULL){
				system("clear");
				printf("\n\n\tError ....overflow!!!!!!");
			}
			 else{
			 	printf("\n\n\tEnter the data : ");
			 	scanf("%d",&(temp->data));
				clear();
			 	temp->next=top;
			 	top=temp;
			 	printf("\n\tAddition successfull.....\n\t");
			 }
			break;
		case 50:temp=(node*)malloc(sizeof(node));
			if(temp==NULL){
				system("clear");
				printf("\n\n\tError ....overflow!!!!!!");	
			}
			else{
				 printf("\n\n\tEnter the data : ");
				 scanf("%d",&(temp->data));
				 clear();
				 temp->next=NULL;
				 temp2=top;
				 while(temp2->next!=NULL)
				 	temp2=temp2->next;
				 temp2->next=temp;
				 printf("\n\tAddition successfull.....\n\t");
			}
			break;
		case 51:temp=(node*)malloc(sizeof(node));
			if(temp==NULL){
				system("clear");
				printf("\n\n\tError ....overflow!!!!!!");	
			}
			else{
				printf("\n\n\tEnter the data : ");
				scanf("%d",&temp->data);
				printf("\n\tEnter the location : ");
				scanf("%d",&loc);
				clear();
				count();
				if(loc>=cnt||loc<0){
					if(loc==cnt)
						printf("\nAddition of data at the end can not be performed");
					else if(loc==1)
						printf("\nAddition of data at the begning can not be performed");
					else
						printf("\n\tLocation does not exist");
					free(temp);
				  }
				else{
				 	 temp2=top;
				 	 for(i=1;i<loc-1;i++)
						temp2=temp2->next;		  
					  temp1=temp2->next;
					  temp2->next=temp;
					  temp->next=temp1;
				  	  printf("\n\tAddition successfull.....\n\t");
				}
				  }
			
			break;
		case 52:
			 printf("\n\n\tAddition of data aborted......!!!!\t");
			 getch();
			 return;	
		}
		getch();
	}
	}	
}

void count()
{
	cnt=0;
	node *temp;
	temp=top;	
	while(temp!=NULL){	
	cnt++;
	temp=temp->next;	
	}
}
void delete()
{	
	node *temp,*temp2;
	int data;
	int ch;
	if(top==NULL)
	{
	system("clear");
	printf("\n\n\tError ...Underflow!!!!!!!!\t");
	}
	else
	{
	system("clear");
	printf("\n\n\tEnter the element to be deleted : ");
	scanf("%d",&data);
	clear();
		temp=top;
		while(temp->data!=data && temp->next!=NULL)
		{
		temp=temp->next;
		}
		if(temp->data==data)
		{
			printf("\n\tDeleting age = %d from the linked list ....to continue press y : ",data);
			ch=getche();
			if((char)ch=='y'||(char)ch=='Y')
			{
				if(temp==top)
				top=NULL;			
				else if(temp->next==NULL)
				temp2->next=NULL;
				else
				temp2->next=temp->next;			
				free(temp);
				printf("\n\tDeletion successfull... \t");
			}
			else
			printf("\n\n\tDeletion of data aborted...!!!\t");
		}
		else
		printf("\n\tElement not found in the linked list\t");	
	}
	getch();
}
void shrt()
{
	node *temp1,*temp2,*temp3;;
	int temp;
	if(top==NULL){
	system("clear");
 	printf("\n\n\tERROR...Underflow!!!!!!!!");
	getch();
	return;
	}
	temp3=NULL;
	temp1=top;
	while(temp1->next!=NULL){
		temp2=top;
		while(temp2->next!=temp3){
			if(temp2->data>temp2->next->data){
				temp=temp2->next->data;
				temp2->next->data=temp2->data;
				temp2->data=temp;	
			}
			temp2=temp2->next;
		}
		temp3=temp2;
		temp1=temp1->next;	
	}
	system("clear");
	printf("\n\n\tShorting successfull....\t");
	getch();

}
int getch(void)
{
    struct termios oldattr, newattr;
    int ch;
    tcgetattr( STDIN_FILENO, &oldattr );
    newattr = oldattr;
    newattr.c_lflag &= ~( ICANON | ECHO );
    tcsetattr( STDIN_FILENO, TCSANOW, &newattr );
    ch = getchar();
    tcsetattr( STDIN_FILENO, TCSANOW, &oldattr );
    return ch;
}
int getche(void)
{
    struct termios oldattr, newattr;
    int ch;
    tcgetattr( STDIN_FILENO, &oldattr );
    newattr = oldattr;
    newattr.c_lflag &= ~( ICANON );
    tcsetattr( STDIN_FILENO, TCSANOW, &newattr );
    ch = getchar();
    tcsetattr( STDIN_FILENO, TCSANOW, &oldattr );
    return ch;
}
void clear()
{
while(getchar()!=10);
}

