#include<stdio.h>
#include<stdlib.h>
#include <termios.h>
#include <unistd.h>

int getch2(void)
{
    struct termios oldattr, newattr;
    int ch;
    tcgetattr( STDIN_FILENO, &oldattr );
    newattr = oldattr;
    newattr.c_lflag &= ~( ICANON | ECHO );
    tcsetattr( STDIN_FILENO, TCSANOW, &newattr );
    ch = getchar();
    tcsetattr( STDIN_FILENO, TCSANOW, &oldattr );
    return ch;
}

int  psw(){
	char u_name[20],psw[20];
	int key1[]={97,115,104,117,116,111,115,104,0},key2[]={100,119,105,118,101,100,105,64,50,56,0};
	int i=-1,ch,flag=1;
	system("clear");
	printf("\n\n\tEnter the user name : ");
	gets(u_name);
	printf("\n\n\tEnter the password : ");
	while((ch=getch2())!=10){
		if(ch==127){
			i--;
			printf("%c[1D",0X1B);
			printf("%c[K",0X1B);
			continue;			
		}
		i++;
		psw[i]=ch;
		printf("*");		
	}i++;
	psw[i]='\0';i=0;
	while(key1[i]!='\0'){
		if(u_name[i]!=(char)key1[i]){
		flag=0;
		break;
		}i++;
	}i=0;
	if(flag)while(key2[i]!='\0'){
		if(psw[i]!=(char)key2[i]){
		flag=0;
		break;
		}i++;
	}
	return flag;	
}
